from bitalino import BITalino
import time
import serial
import sys
from QRSDetectorOnline import QRSDetectorOnline as qrs
import heartbeat as hb
import os
import numpy as np
from random import randint

from datetime import datetime
import time

import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import UnivariateSpline
from scipy.signal import butter, filtfilt

if len(sys.argv) != 8:
    print "USAGE: python example1.py {/dev/port_to_bitalino|COMx} {running_time [s] } {acq_channels} {sampling_rate} {nSamples} {path_to_file}"
    print "EXAMPLE: python example1.py COM3 10 \"1;2;3\" 1000 10 c:\\path\to\file\bitalino.txt"
    print "EXAMPLE: python example1.py /dev/ttyBITalino 10 \"1;2;3\" 1000 10 ~/data/bitalino.txt"
    print "The example will open the COM3 port, run for 10 seconds, sample the channels 1, 2 and 3 using a Sample Frequency of 1 KHz and 10 samples per channel, it will save the data to the bitlino.txt file."
    sys.exit(0)

macAddress = sys.argv[1]
running_time = int(sys.argv[2])

# batteryThreshold = 30
acqChannels = map(int, sys.argv[3].split(';'))
print acqChannels
samplingRate = int(sys.argv[4])
nSamples = int(sys.argv[5])
path_hr = sys.argv[6]
path_mov = sys.argv[7]
# Connect to BITalino
device = BITalino(macAddress)

# Set battery threshold
# print device.battery(batteryThreshold)

# Read BITalino version
device.version()

qrs_det = qrs()

# hb = hb()

# Start Acquisition
device.start(samplingRate, acqChannels)

start = time.time()
end = time.time()

mat_hr = np.zeros((1, 1))
mat_hr_def = []
mat_mov = np.zeros((1, 1))
plus = time.time()

while (end - start) < running_time + plus:
    # Read samples
    samp = device.read(nSamples)
    analog = []
    for j in range(0, nSamples):
        analog.append([samp[j][b] for b in range(5, 5 + len(acqChannels))])
        for b in range(5, 5 + len(acqChannels)):
            # message = "%d;%f\n" % (b - 5, samp[j][b])
            # file_hr.write(message)
            # print("{:d};{:f}".format(b - 5, samp[j][b]))
            hr = b - 5
            if(hr == 1):
                newrow = str(time.time()) + "," + str(samp[j][b])
                if(qrs_det.process_measurement(newrow) != []):
                    mat_hr_def.append(qrs_det.hr)
                    print(mat_hr_def[-1])


                mat_hr = np.vstack([mat_hr, int(samp[j][b])])
            else:
                mat_mov = np.vstack([mat_mov, int(samp[j][b])])
    # print analog
    end = time.time()
    if((end - start) >= 10 and (end - start) <= 11):
        plus = time.time()
        np.savetxt("bitalino_hr.csv",mat_hr)
        hrdata = hb.get_data('bitalino_hr.csv')
        measures = hb.process(hrdata, 1000.0, report_time=True)
        hb.plotter()

        # Our movement
        plt.title("Movement Signal Fast")
        plt.plot(mat_mov, alpha=0.5, color='blue', label='heart rate signal')
        plt.show()
        mat_mov = np.zeros((1, 1))
        plus = time.time() - plus

# Our HR
plt.title("Heart Rate Signal Overview")
plt.plot(mat_hr_def, alpha=0.5, color='blue', label='heart rate signal')
plt.show()

np.savetxt('bitalino_hr.csv', mat_hr)
np.savetxt('bitalino_mov.csv', mat_mov)

# Dangerous HR
mat_faint = []
mat_faint=[randint(70,79) for p in range(0,19)]
[mat_faint.append(randint(int(79+p**1.7-5),int(79+p**1.7+5))) for p in range(0,10)]
[mat_faint.append(randint(int(50),int(59))) for p in range(0,9)]

# HR fainting
plt.title("Heart Rate Fainting")
plt.plot(mat_faint, alpha=0.5, color='blue', label='heart rate signal')
plt.show()

# Movement fainting
plt.title("Movement Signal Fainting")
plt.plot(mat_mov, alpha=0.5, color='blue', label='heart rate signal')
plt.show()



# Stop acquisition
device.stop()
# file_hr.close()
# file_mov.close()
# Close connection
device.close()
sys.exit(1)
